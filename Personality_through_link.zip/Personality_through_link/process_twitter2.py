

from googlesearch import search
import bs4
import urllib2
import sys

from fake_useragent import UserAgent
import urllib2


def sites(search_name):
	
	url_list = []
	

	search_key = search_name +" " +'twitter'


	for url in search(search_key, tld='com.pk', lang='es', stop=4):

		url_list.append(url)

	

	all_url="\n\n".join(url_list)

	
	tweet_list = []

	for j in url_list:

		if "//twitter.com/" in j:
			tweet_list.append(j)
		else:
			pass
		
	print("twitter list : ",tweet_list)

	

	#print(all_url)
	


	
	return tweet_list


#r = sites("vivek mannige","acceltree")
#print(r)





























