
# -*- coding: utf-8 -*-

#========================== Importing Required Libraries =============================
 
from flask import Flask
import os
from flask import Flask, request, redirect, url_for, render_template, send_from_directory,send_file
from werkzeug.utils import secure_filename

import matplotlib
matplotlib.use("Agg")

import json
import matplotlib.pyplot as plt

import nltk
import string
from nltk.classify import NaiveBayesClassifier
from wordcloud.wordcloud import WordCloud, STOPWORDS

import numpy as np
import pandas as pd
import pickle
import re
import fileinput

import sys
reload(sys)
sys.setdefaultencoding('utf8')


import datetime
import cx_Oracle


#=======================  Importing Programs ==================================


import process_twitter2
import tweet_text





#====================  Pre-Loading the Weight Files ==========================

f = open('IntroExtronew.pickle', 'rb')
IntroExtro = pickle.load(f)
f.close()
print('1')

f= open('IntuitionSensingnew.pickle', 'rb')
IntuitionSensing = pickle.load(f)
f.close()
print('2')

f= open('ThinkingFeelingnew.pickle', 'rb')
ThinkingFeeling = pickle.load(f)
f.close()
print('3')

    
f = open('JudgingPercieivingnew.pickle', 'rb')
JudgingPercieiving = pickle.load(f)
f.close()
print('4')


#===================== Defining Functions ===============================

alphabets= "([A-Za-z])"
prefixes = "(Mr|St|Mrs|Ms|Dr)[.]"
suffixes = "(Inc|Ltd|Jr|Sr|Co)"
starters = "(Mr|Mrs|Ms|Dr|He\s|She\s|It\s|They\s|Their\s|Our\s|We\s|But\s|However\s|That\s|This\s|Wherever)"
acronyms = "([A-Z][.][A-Z][.](?:[A-Z][.])?)"
websites = "[.](com|net|org|io|gov)"



def MBTI(input):

    tokenize = build_bag_of_words_features_filtered(input)
    ie = IntroExtro.classify(tokenize)
    Is = IntuitionSensing.classify(tokenize)
    tf = ThinkingFeeling.classify(tokenize)
    jp = JudgingPercieiving.classify(tokenize)
    
    mbt = ''
    
    if(ie == 'introvert'):
        mbt+='Introvert'
    if(ie == 'extrovert'):
        mbt+='Extrovert'
    if(Is == 'Intuition'):
        mbt+='Intuition(N)'
    if(Is == 'Sensing'):
        mbt+='Sensing'
    if(tf == 'Thinking'):
        mbt+='Thinking'
    if(tf == 'Feeling'):
        mbt+='Feeling'
    if(jp == 'Judging'):
        mbt+='Judging'
    if(jp == 'Percieving'):
        mbt+='Percieving'
    return(mbt)


def Merge(dict1, dict2): 
    return(dict2.update(dict1))



def tellmemyMBTI(input, name, traasits=[]):
    a = []
    trait1 = pd.DataFrame([0,0,0,0],['Introvert','Intuition(N)','Thinking','Judging'],['count'])
    trait2 = pd.DataFrame([0,0,0,0],['Extrovert','Sensing','Feeling','Percieving'],['count'])
    for i in input:
        a += [MBTI(i)]
    for i in a:
        for j in ['Introvert','Intuition(N)','Thinking','Judging']:
            if(j in i):
                trait1.loc[j]+=1                
        for j in ['Extrovert','Sensing','Feeling','Percieving']:
            if(j in i):
                trait2.loc[j]+=1 
    trait1 = trait1.T
    trait1 = trait1*100/len(input)
    trait2 = trait2.T
    trait2 = trait2*100/len(input)
    
    
    #Finding the personality
    YourTrait = ''
    for i,j in zip(trait1,trait2):
        temp = max(trait1[i][0],trait2[j][0])
        if(trait1[i][0]==temp):
            YourTrait += i  
        if(trait2[j][0]==temp):
            YourTrait += j
    #traasits +=[YourTrait] 
    traasits =[YourTrait]
    
    #Plotting
    
    labels = np.array(results.columns)

    intj = trait1.loc['count']
    print("intj : ",intj)

    #print("intj dict : " ,dict(intj))

    dict_intj = dict(intj)

    ind = np.arange(4)
    width = 0.4

    fig = plt.figure()
    ax = fig.add_subplot(111)
    rects1 = ax.bar(ind, intj, width, color='royalblue')

    esfp = trait2.loc['count']
    print("esfp : ",esfp)

    dict_esfp = dict(esfp)
    #print("esfp dict : ",dict(esfp))

    combine_dict = Merge(dict_intj,dict_esfp)
    #print("combine dictionary : ",dict_esfp)

    merge_dict = {}

    for key,value in dict_esfp.items():
        if key == "Introvert":
	    merge_dict.update({key:value})
	elif key == "Extrovert":
	    merge_dict.update({key:value})
	elif key == "Intuition":
	    merge_dict.update({key:value})
	elif key == "Sensing":
	    merge_dict.update({key:value})
	elif key == "Thinking":
	    merge_dict.update({key:value})
	elif key == "Feeling":
	    merge_dict.update({key:value})
	elif key == "Judging":
	    merge_dict.update({key:value})
	elif key == "Perceiving":
	    merge_dict.update({key:value})
	else:
	    pass

    print("merge dict : ",merge_dict)
    
    rects2 = ax.bar(ind+width, esfp, width, color='seagreen')

    fig.set_size_inches(8, 3)
    
    

    #ax.set_xlabel('Finding the MBTI Trait', size = 18)
    ax.set_ylabel('Trait Percent (%)', size = 18)
    ax.set_xticks(ind + width / 2)
    ax.set_xticklabels(labels)
    ax.set_yticks(np.arange(0,105, step= 10))
    ax.set_title('Your Personality is '+YourTrait,size = 20)
    plt.grid(True)
    
    
    fig.savefig("static/people_photo/" + name+'.png', dpi=200)
    #fig.savefig("static/" + name+'.png', dpi=200)
    #plt.show()

    return traasits,dict_esfp

    #return traasits,merge_dict



useless_words = nltk.corpus.stopwords.words("english") + list(string.punctuation)
def build_bag_of_words_features_filtered(words):
    	words = nltk.word_tokenize(words)
    	return {
        	word:1 for word in words \
        	if not word in useless_words}








temp = {'train' : [81.12443979837917,70.14524215640667,80.03456948570128,79.79341109742592], 'test' : [58.20469312585358,54.46262259027357,59.41315234035509,54.40549600629061]}

results = pd.DataFrame.from_dict(temp, orient='index', columns=['Introvert - Extrovert', 'Intuition - Sensing', 'Thinking - Feeling', 'Judging - Percieiving'])




def split_into_sentences(text):


    text = " " + text + "  "
    text = text.replace("\n"," ")

    text = re.sub(prefixes,"\\1<prd>",text)
    text = re.sub(websites,"<prd>\\1",text)
    if "Ph.D" in text: text = text.replace("Ph.D.","Ph<prd>D<prd>")
    text = re.sub("\s" + alphabets + "[.] "," \\1<prd> ",text)
    text = re.sub(acronyms+" "+starters,"\\1<stop> \\2",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>\\3<prd>",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>",text)
    text = re.sub(" "+suffixes+"[.] "+starters," \\1<stop> \\2",text)
    text = re.sub(" "+suffixes+"[.]"," \\1<prd>",text)
    text = re.sub(" " + alphabets + "[.]"," \\1<prd>",text)
    if "”" in text: text = text.replace(".”","”.")
    if "\"" in text: text = text.replace(".\"","\".")
    if "!" in text: text = text.replace("!\"","\"!")
    if "?" in text: text = text.replace("?\"","\"?")
    text = text.replace(".",".<stop>")
    text = text.replace("?","?<stop>")
    text = text.replace("!","!<stop>")
    text = text.replace("<prd>",".")
    sentences = text.split("<stop>")
    sentences = sentences[:-1]
    sentences = [s.strip() for s in sentences]
    return sentences



#=========   Flask Initialisation , Defining Path for Images and Oracle Database Connection  ==========

application = Flask(__name__, static_url_path="/static")

PEOPLE_FOLDER = os.path.join('static', 'people_photo')

GRAPH_FOLDER = os.path.join('static', 'blog_photo')

application.config['UPLOAD_FOLDER'] = PEOPLE_FOLDER

application.config['BLOG_FOLDER'] = GRAPH_FOLDER



#con=cx_Oracle.connect('pamb/pamb@115.112.176.59/accelife')

#con=cx_Oracle.connect('accelifeglobal/accelifeglobal@115.112.176.59:1521/accelife')

#cursor=con.cursor()

#cust_id=1






#======================= Fetching Demographic Information from Linkedin Profile ==================

@application.route("/")

def demographic():

	return render_template('form_1.html')	

	
	
#================== Personality Insights from Twitter Data ========================

	
@application.route("/personality" , methods=['GET','POST'])


def twitter_personality():

	if request.method=="POST":

		
		name = request.form.get('link')

		print("name : ",name)

		

		t_res  = process_twitter2.sites(name)

		while t_res == []:
			return render_template('index2.html')

		tlist = []

		for t in t_res:
			t_str = t.split("/")
			t_link = t_str[3]

			tlist.append(name + "@" + t_link)
		
		print("tlist : " ,tlist)

		
		return render_template('form_2.html', data=tlist)




	

@application.route("/personality_graph" , methods=['GET','POST'])

def personality_view():

	if request.method=="POST":
		
		text3 = request.form.get('text1')
		print("text3 : ",text3)

		text3 = text3.encode("utf-8")
		text3 = eval(text3)
		

		link = request.form.get('website')

		print("save twitter link : ",link) #u'vivek mannige@entmobility'

		personal_link = request.form.get('link')
		
		print("personal link : " , personal_link)

		if personal_link != '':

			#link1_str = personal_link.split("/")
			#print("hey : " ,link1_str)
			#tweet_link = link1_str[3]
			#res1 = tweet_text.get_all_tweets(tweet_link)

			res1 = tweet_text.get_all_tweets(personal_link)
			
			print(res1)
			
			res1 = re.sub(r"http\S+", "", res1)
	
			print("res1 : ",res1)

			if res1 == "Not enough words for analyzing":
				return "Not enough words for analyzing"



			with open("Output.txt", "w") as text_file:
    				text_file.write(res1)

			text_file.close()

			for line in fileinput.FileInput("Output.txt",inplace=1):
        			if line.rstrip():
            				print(line)

			with open("Output.txt", 'rb') as f:
     				my_writing = [l.decode('utf8', 'ignore') for l in f.readlines()]


			my_posts = split_into_sentences(my_writing[0])
			
			#my_posts = my_writing
		
			print("my_posts : ",my_posts)

			uniq_filename = str(datetime.datetime.now().date()) + '_' + str(datetime.datetime.now().time()).replace(':', '.') 

			trait=tellmemyMBTI(my_posts, uniq_filename)

			print("trait : " ,trait)

			#lista = trait[1]

			

			listb = [ [k,v] for k, v in trait[1].items() ]

			dict_list = ['0','0','0','0','0','0','0','0']

			for i in listb:
				if i[0] == "Introvert":
					dict_list[0] = [i[0],int(i[1])]

				elif i[0] == "Extrovert":
					dict_list[1] = [i[0],int(i[1])]

				elif i[0] == "Intuition(N)":
					dict_list[2] = [i[0],int(i[1])]

				elif i[0] == "Sensing":
					dict_list[3] = [i[0],int(i[1])]


				elif i[0] == "Thinking":
					dict_list[4] = [i[0],int(i[1])]

				elif i[0] == "Feeling":
					dict_list[5] = [i[0],int(i[1])]

				
				elif i[0] == "Judging":
					dict_list[6] = [i[0],int(i[1])]

				elif i[0] == "Percieving":
					dict_list[7] = [i[0],int(i[1])]

				else:
					pass

			dict_list.insert(0,['Traits','Traits Percent'])


			print(dict_list)




			res_str = "".join(trait[0])
		
			print("res_str : ",res_str)

			if "Introvert" in res_str:

				if "Introvert" and "Sensing" in res_str:
					personality = "Reluctant to buy new products.Not likely to be tempted by new products.Quite and private.Avoid risk and pay more attention to the negative aspects of their environment.Focus on the present.See the things as they are and trust what is certain.Like ideas with practical applications.Also like to buy known products." 

					personality_table = "Reluctant to buy new products.Not likely to be tempted by new products.Avoid risk and like to buy known products."

				if "Introvert" and "Thinking" in res_str:
					personality = "Reluctant to buy new products.Not likely to be tempted by new products.Quite and private.Avoid risk and pay more attention to the negative aspects of their environment.Focus on the present.Believe on good logical argument,understand the issue and focus on the steps taken to resolve it.Objective.Make decisions based on facts.Ruled by your head instead of your heart.Judge situations and others based on logic.Value truth over tact and can easily identify flaws."

					personality_table = "Reluctant to buy new products.Not likely to be tempted by new products.Avoid risk and like to buy known products."

				if "Introvert" and "Feeling" in res_str:
					personality = "Reluctant to buy new products.Not likely to be tempted by new products.Likely to buy only planned products.Prefer empathy and reassurance rather than hard steps to resolution.Subjective.Make decisions based on principles and values.Ruled by your heart instead of your head.Judge situations and others based on feelings and extenuating circumstances.Seek to please others and want to be appreciated.Value harmony and empathy."

					personality_table = "Reluctant to buy new products.Not likely to be tempted by new products.Avoid risk and like to buy known products."

			
			elif "Extrovert" in res_str:

				if "Extrovert" and "Feeling" in res_str:
					personality = "Willing to buy new products.Likely to be tempted towards new products.Likely to buy unplanned/unknown products.Talkative and outgoing.Attracted to rewards and tend to see their environment from a more positive perspective.Motivated by gaining rewards. Prefer empathy and reassurance rather than hard steps to resolution.Subjective.Make decisions based on principles and values.Ruled by your heart instead of your head.Judge situations and others based on feelings and extenuating circumstances.Seek to please others and want to be appreciated.Value harmony and empathy."

					personality_table = "Willing to buy new products.Likely to be tempted towards new products.Likely to buy unplanned/unknown products."


				if "Extrovert" and "Thinking" in res_str:
					personality = "You are willing to buy new products. You are likely to be tempted towards new products. You are likely to buy unplanned/unknown products.You believe on good logical argument , understand the issue and focus on the steps taken to resolve it.You tend to be talkative and outgoing . You are attracted to rewards and tend to see their environment from a more positive perspective. You are motivated by gaining rewards.You are subjective. You make decisions based on principles and values. You are ruled by their heart instead of their head.You judge situations and others based on feelings and extenuating circumstances. You seek to please others and want to be appreciated. You value harmony and empathy.You focus on the present.You believe on good logical argument , understand the issue and focus on the steps taken to resolve it.You are objective. You make decisions based on facts. You are ruled by your head instead of your heart.You value truth over tact and can easily identify flaws."

					personality_table = "Willing to buy new products.Likely to be tempted towards new products.Likely to buy unplanned/unknown products."

		
			full_filename = os.path.join(application.config['UPLOAD_FOLDER'], uniq_filename)

			print(full_filename)

			personality_list = personality.split(".")
			print("personality list : ",personality_list)


			
			return render_template('form_22.html',user_image = full_filename + ".png", trait = personality_list , data=text3 , data1 = dict_list )



		else:
		

			if link == None:
				return "Sorry...kindly select the url for processing.."


			else:
				link1_str = link.split("@")
				tweet_link = link1_str[1]
				res1 = tweet_text.get_all_tweets(tweet_link)
			
				res1 = re.sub(r"http\S+", "", res1)

				if res1 == "Not enough words for analyzing":
					return "Not enough words for analyzing"

				with open("Output.txt", "w") as text_file:
    					text_file.write(res1)

				text_file.close()

				for line in fileinput.FileInput("Output.txt",inplace=1):
        				if line.rstrip():
            					print(line)

				with open("Output.txt", 'rb') as f:
     					my_writing = [l.decode('utf8', 'ignore') for l in f.readlines()]


				my_posts = split_into_sentences(my_writing[0])
		
				print("my_posts : ",my_posts)

				uniq_filename = str(datetime.datetime.now().date()) + '_' + str(datetime.datetime.now().time()).replace(':', '.') 

				trait=tellmemyMBTI(my_posts, uniq_filename)

				
				listb = [ [k,v] for k, v in trait[1].items() ]

				dict_list = ['0','0','0','0','0','0','0','0']

				for i in listb:
					if i[0] == "Introvert":
						dict_list[0] = [i[0],int(i[1])]

					elif i[0] == "Extrovert":
						dict_list[1] = [i[0],int(i[1])]

					elif i[0] == "Intuition(N)":
						dict_list[2] = [i[0],int(i[1])]

					elif i[0] == "Sensing":
						dict_list[3] = [i[0],int(i[1])]


					elif i[0] == "Thinking":
						dict_list[4] = [i[0],int(i[1])]

					elif i[0] == "Feeling":
						dict_list[5] = [i[0],int(i[1])]

					
					elif i[0] == "Judging":
						dict_list[6] = [i[0],int(i[1])]

					elif i[0] == "Percieving":
						dict_list[7] = [i[0],int(i[1])]

					else:
						pass

				dict_list.insert(0,['Traits','Traits Percent'])


				print(dict_list)


				

				res_str = "".join(trait[0])

				if "Introvert" in res_str:

					if "Introvert" and "Sensing" in res_str:
						personality = "Reluctant to buy new products.Not likely to be tempted by new products.Quite and private.Avoid risk and pay more attention to the negative aspects of their environment.Focus on the present.See the things as they are and trust what is certain.Like ideas with practical applications.Also like to buy known products." 

						
					if "Introvert" and "Thinking" in res_str:
						personality = "Reluctant to buy new products.Not likely to be tempted by new products.Quite and private.Avoid risk and pay more attention to the negative aspects of their environment.Focus on the present.Believe on good logical argument,understand the issue and focus on the steps taken to resolve it.Objective.Make decisions based on facts.Ruled by your head instead of your heart.Judge situations and others based on logic.Value truth over tact and can easily identify flaws."

						
					if "Introvert" and "Feeling" in res_str:
						personality = "Reluctant to buy new products.Not likely to be tempted by new products.Likely to buy only planned products.Prefer empathy and reassurance rather than hard steps to resolution.Subjective.Make decisions based on principles and values.Ruled by your heart instead of your head.Judge situations and others based on feelings and extenuating circumstances.Seek to please others and want to be appreciated.Value harmony and empathy."

						
				elif "Extrovert" in res_str:

					if "Extrovert" and "Feeling" in res_str:
						personality = "Willing to buy new products.Likely to be tempted towards new products.Likely to buy unplanned/unknown products.Prefer empathy and reassurance rather than hard steps to resolution."

						
					if "E" and "Thinking" in res_str:
						personality = "Willing to buy new products.Likely to be tempted towards new products.Likely to buy unplanned/unknown products.Believe on good logical argument , understand the issue and focus on the steps taken to resolve it."

						
		
				full_filename = os.path.join(application.config['UPLOAD_FOLDER'], uniq_filename)

				print(full_filename)

					
				personality_list = personality.split(".")
				print("personality list : ",personality_list)


			

				


				return render_template('form_22.html',user_image = full_filename + ".png", trait = personality_list , data=text3 , data1 = dict_list)

				
	return render_template('form_2.html')

			








if __name__ == "__main__":
    application.debug=True
    application.run(host='0.0.0.0',port=7000 , use_reloader=False)

















