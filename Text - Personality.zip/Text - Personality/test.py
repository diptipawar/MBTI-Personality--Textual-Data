
# coding: utf-8

# In[23]:

import matplotlib
matplotlib.use("Agg")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import nltk
import string
from nltk.classify import NaiveBayesClassifier

import pickle
import re
import os
import fileinput

# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')


#-------------------------------------------------------------

alphabets= "([A-Za-z])"
prefixes = "(Mr|St|Mrs|Ms|Dr)[.]"
suffixes = "(Inc|Ltd|Jr|Sr|Co)"
starters = "(Mr|Mrs|Ms|Dr|He\s|She\s|It\s|They\s|Their\s|Our\s|We\s|But\s|However\s|That\s|This\s|Wherever)"
acronyms = "([A-Z][.][A-Z][.](?:[A-Z][.])?)"
websites = "[.](com|net|org|io|gov)"



f = open('IntroExtronew.pickle', 'rb')
IntroExtro = pickle.load(f)
f.close()
print('1')

f= open('IntuitionSensingnew.pickle', 'rb')
IntuitionSensing = pickle.load(f)
f.close()
print('2')

f= open('ThinkingFeelingnew.pickle', 'rb')
ThinkingFeeling = pickle.load(f)
f.close()
print('3')

    
f = open('JudgingPercieivingnew.pickle', 'rb')
JudgingPercieiving = pickle.load(f)
f.close()
print('4')



def MBTI(input):



    tokenize = build_bag_of_words_features_filtered(input)
    ie = IntroExtro.classify(tokenize)
    Is = IntuitionSensing.classify(tokenize)
    tf = ThinkingFeeling.classify(tokenize)
    jp = JudgingPercieiving.classify(tokenize)
    
    mbt = ''
    
    if(ie == 'introvert'):
        mbt+='I'
    if(ie == 'extrovert'):
        mbt+='E'
    if(Is == 'Intuition'):
        mbt+='N'
    if(Is == 'Sensing'):
        mbt+='S'
    if(tf == 'Thinking'):
        mbt+='T'
    if(tf == 'Feeling'):
        mbt+='F'
    if(jp == 'Judging'):
        mbt+='J'
    if(jp == 'Percieving'):
        mbt+='P'
    return(mbt)
    

#----------------------------------------------------------------



def tellmemyMBTI(input, name, traasits=[]):
    a = []
    trait1 = pd.DataFrame([0,0,0,0],['I','N','T','J'],['count'])
    trait2 = pd.DataFrame([0,0,0,0],['E','S','F','P'],['count'])
    for i in input:
        a += [MBTI(i)]
    for i in a:
        for j in ['I','N','T','J']:
            if(j in i):
                trait1.loc[j]+=1                
        for j in ['E','S','F','P']:
            if(j in i):
                trait2.loc[j]+=1 
    trait1 = trait1.T
    trait1 = trait1*100/len(input)
    trait2 = trait2.T
    trait2 = trait2*100/len(input)
    
    
    #Finding the personality
    YourTrait = ''
    for i,j in zip(trait1,trait2):
        temp = max(trait1[i][0],trait2[j][0])
        if(trait1[i][0]==temp):
            YourTrait += i  
        if(trait2[j][0]==temp):
            YourTrait += j
    #traasits +=[YourTrait] 
    traasits =[YourTrait]
    
    #Plotting
    
    labels = np.array(results.columns)

    intj = trait1.loc['count']
    print("intj : ",intj)



    dict_intj = dict(intj)

    






    ind = np.arange(4)
    width = 0.4

    fig = plt.figure()
    ax = fig.add_subplot(111)
    rects1 = ax.bar(ind, intj, width, color='royalblue')

    esfp = trait2.loc['count']
    print("esfp : ",esfp)
    rects2 = ax.bar(ind+width, esfp, width, color='seagreen')

    fig.set_size_inches(8, 3)
    
    

    #ax.set_xlabel('Finding the MBTI Trait', size = 18)
    ax.set_ylabel('Trait Percent (%)', size = 18)
    ax.set_xticks(ind + width / 2)
    ax.set_xticklabels(labels)
    ax.set_yticks(np.arange(0,105, step= 10))
    ax.set_title('Your Personality is '+YourTrait,size = 20)
    plt.grid(True)
    
    
    fig.savefig("static/people_photo/" + name+'.png', dpi=200)
    #fig.savefig("static/" + name+'.png', dpi=200)
    #plt.show()

    return traasits


#------------------------------------------------------------------
        


useless_words = nltk.corpus.stopwords.words("english") + list(string.punctuation)
def build_bag_of_words_features_filtered(words):
    	words = nltk.word_tokenize(words)
    	return {
        	word:1 for word in words \
        	if not word in useless_words}


temp = {'train' : [81.12443979837917,70.14524215640667,80.03456948570128,79.79341109742592], 'test' : [58.20469312585358,54.46262259027357,59.41315234035509,54.40549600629061]}

results = pd.DataFrame.from_dict(temp, orient='index', columns=['Introvert - Extrovert', 'Intuition - Sensing', 'Thinking - Feeling', 'Judging - Percieiving'])

#----------------------------------------------------------------
												
													
def split_into_sentences(text):

    



    text = " " + text + "  "
    text = text.replace("\n"," ")
    #text = text.replace("\t\t"," ")
    text = re.sub(prefixes,"\\1<prd>",text)
    text = re.sub(websites,"<prd>\\1",text)
    if "Ph.D" in text: text = text.replace("Ph.D.","Ph<prd>D<prd>")
    text = re.sub("\s" + alphabets + "[.] "," \\1<prd> ",text)
    text = re.sub(acronyms+" "+starters,"\\1<stop> \\2",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>\\3<prd>",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>",text)
    text = re.sub(" "+suffixes+"[.] "+starters," \\1<stop> \\2",text)
    text = re.sub(" "+suffixes+"[.]"," \\1<prd>",text)
    text = re.sub(" " + alphabets + "[.]"," \\1<prd>",text)
    if "”" in text: text = text.replace(".”","”.")
    if "\"" in text: text = text.replace(".\"","\".")
    if "!" in text: text = text.replace("!\"","\"!")
    if "?" in text: text = text.replace("?\"","\"?")
    text = text.replace(".",".<stop>")
    text = text.replace("?","?<stop>")
    text = text.replace("!","!<stop>")
    text = text.replace("<prd>",".")
    sentences = text.split("<stop>")
    sentences = sentences[:-1]
    sentences = [s.strip() for s in sentences]
    return sentences

#------------------------------------------------------------------------


def personality(filename):

	for line in fileinput.FileInput(filename,inplace=1):
        	if line.rstrip():
            		print(line)

	with open(filename, 'rb') as f:
     		my_writing = [l.decode('utf8', 'ignore') for l in f.readlines()]


	#my_posts = my_writing[0].split('|||')

	


	my_posts = split_into_sentences(my_writing[0])

	#my_posts = re.split('. , ... ! ?',my_writing[0])
	print(my_posts)
	len(my_posts)
	#my_posts




	name1 = filename.split(".")
	name_str = "".join(name1[0])
	#trait=tellmemyMBTI(my_posts, name_str)

	trait=tellmemyMBTI(my_posts, 'zzz')


	return trait 





r = personality("vivek_sir_tweets.txt")
print(r)





"""
with open("Sanayapoem.txt", 'rb') as f:
     my_writing = [l.decode('utf8', 'ignore') for l in f.readlines()]


# In[34]:


my_posts = my_writing[0].split('|||')
len(my_posts)
#my_posts


# In[35]:


trait = tellmemyMBTI(my_posts,'sanaya')

"""












