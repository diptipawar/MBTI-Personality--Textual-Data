
#!/usr/bin/env python
# encoding: utf-8

import tweepy #https://github.com/tweepy/tweepy
import csv
from textblob import TextBlob 
import re

#Twitter API credentials

consumer_key = "oJfRBoPmjufmSacazYcHEqh4U"
consumer_secret = "tn4T7O2MzF0XveenRzG0M64jIG12KrBPp7ep9cwic4ghNuiZCv"
access_key = "1114019946470580224-efTG0vATF9sdh7N4hSXLHqmERGuXBU"
access_secret = "xMxyBaPvdhKedgsR0z80tnnyDr2xpicljiBKdfXDwjLO0"



def get_all_tweets(name):

	try:
		total_tweets=[]


		auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
		auth.set_access_token(access_key, access_secret)
		api = tweepy.API(auth)
	

		alltweets = []	
		all_words = []

		new_tweets = api.user_timeline(screen_name = name,count=200)
	

		alltweets.extend(new_tweets)
	

		oldest = alltweets[-1].id - 1
	

		while len(new_tweets) > 0:
			
			new_tweets = api.user_timeline(screen_name = name,count=200,max_id=oldest)
		
			alltweets.extend(new_tweets)
		
			oldest = alltweets[-1].id - 1
		

		outtweets = [[tweet.id_str, tweet.created_at, tweet.text.encode("utf-8")] for tweet in alltweets]



		for a in alltweets:
			all_words.append(a.text)
			
			r = ".".join(all_words)
		
			r = re.sub(' +',' ',r)

			r = r.replace("\n","")
			

		#print("allwords : ",all_words)

		all_words_str = " ".join(all_words)
		print(all_words_str)

		all_words_str_list = all_words_str.split(" ")

		print(len(all_words_str_list))

		if len(all_words_str_list) > 200:
        
			for tweet in alltweets:
				
				#print("tweet : ",tweet.text)
   		
				total_tweets.append(tweet.text)
				

				r = ".".join(total_tweets)
		
				r = re.sub(' +',' ',r)

				r = r.replace("\n","")

			#print(len(total_tweets))

		else:
			r = "Not enough words for analyzing"

	except tweepy.error.TweepError:
		r = ''
	

	return r

	  


r= get_all_tweets("lyricist_vivek?lang=es")
print(r)


