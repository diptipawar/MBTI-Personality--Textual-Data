

import schedule
import time
from datetime import datetime
#import a1
#import cx_Oracle
#import threading
#import combine

import combine_linkedin
#import combine_twitter


def job():
    print("I'm working...")
    reload(combine_linkedin)
    #reload(combine_twitter)
schedule.every(10).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)




