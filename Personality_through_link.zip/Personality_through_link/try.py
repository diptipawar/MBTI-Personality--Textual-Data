
lista = [['IntrovertIntuition(N)ThinkingPercieving'], {'Thinking': 86.20689655172414, 'Extrovert': 24.137931034482758, 'Introvert': 75.86206896551724, 'Judging': 31.03448275862069, 'Percieving': 68.96551724137932, 'Feeling': 13.793103448275861, 'Sensing': 13.793103448275861, 'Intuition(N)': 86.20689655172414}]







listb = [ [k,v] for k, v in lista[1].items() ]





dict_list = ['0','0','0','0','0','0','0','0']

for i in listb:
	if i[0] == "Introvert":
		dict_list[0] = [i[0],int(i[1])]

	elif i[0] == "Extrovert":
		dict_list[1] = [i[0],i[1]]

	elif i[0] == "Thinking":
		dict_list[2] = [i[0],i[1]]

	elif i[0] == "Feeling":
		dict_list[3] = [i[0],i[1]]

	elif i[0] == "Intuition(N)":
		dict_list[4] = [i[0],i[1]]

	elif i[0] == "Sensing":
		dict_list[5] = [i[0],i[1]]

	elif i[0] == "Judging":
		dict_list[6] = [i[0],i[1]]

	elif i[0] == "Percieving":
		dict_list[7] = [i[0],i[1]]
	else:
		pass


dict_list.insert(0,['Traits','Traits Percent'])

#dict_list = filter(lambda a: a != '0', dict_list)

print(dict_list)





