
# -*- coding: utf-8 -*-

#!/usr/bin/env python
# encoding: utf-8

import tweepy #https://github.com/tweepy/tweepy
import csv
from textblob import TextBlob 

from ibm_watson import PersonalityInsightsV3
import json

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import re

#Twitter API credentials

consumer_key = "oJfRBoPmjufmSacazYcHEqh4U"
consumer_secret = "tn4T7O2MzF0XveenRzG0M64jIG12KrBPp7ep9cwic4ghNuiZCv"
access_key = "1114019946470580224-efTG0vATF9sdh7N4hSXLHqmERGuXBU"
access_secret = "xMxyBaPvdhKedgsR0z80tnnyDr2xpicljiBKdfXDwjLO0"






    	



def get_all_tweets(name):

	try:
		
		total_tweets=[]
	
		url = 'https://gateway.watsonplatform.net/personality-insights/api'

		apikey = 'Wcp-qDUY7OKpM6EUnA_15Aj4OzyAgGkxnq6VFfJR3joa'

		service = PersonalityInsightsV3(url=url, iam_apikey=apikey, version='2017-10-13' )

		auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
		auth.set_access_token(access_key, access_secret)
		api = tweepy.API(auth)

		alltweets = []

		new_tweets = api.user_timeline(screen_name = name,count=200)

		alltweets.extend(new_tweets)

		if alltweets!=[]:

			oldest = alltweets[-1].id - 1

		
			while len(new_tweets) > 0:
		
				new_tweets = api.user_timeline(screen_name = name,count=200,max_id=oldest)
				alltweets.extend(new_tweets)
				oldest = alltweets[-1].id - 1


			outtweets = [[tweet.id_str, tweet.created_at, tweet.text.encode("utf-8")] for tweet in alltweets]

		for tweet in alltweets:
			
			

			total_tweets.append(tweet.text)

    			
		r = ".".join(total_tweets)
		
		r = re.sub(' +',' ',r)

		r = r.replace("\n","")

	except tweepy.error.TweepError:
		r = ''
	

	return r




#r = get_all_tweets("g1_jadhav")

#print(r.strip())

#r = re.sub(' +',' ',r)

#r = r.replace("\n","")


#print(r)

























